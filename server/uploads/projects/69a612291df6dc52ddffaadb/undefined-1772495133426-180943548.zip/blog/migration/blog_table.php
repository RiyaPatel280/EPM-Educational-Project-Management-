<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Migration_Blog_table extends CI_Migration
{
    public function up()
    {
        $this->dbforge->add_field([
            'id' => ['type' => 'INT', 'auto_increment' => TRUE],
            'name' => ['type' => 'VARCHAR', 'constraint' => 255],
            'description' => ['type' => 'TEXT', 'null' => TRUE],
            'datecreated' => ['type' => 'DATETIME', 'default' => 'CURRENT_TIMESTAMP'],
        ]);
        $this->dbforge->add_key('id', TRUE);
        $this->dbforge->create_table('blogs');
    }

    public function down()
    {
        $this->dbforge->drop_table('blogs');
    }
}