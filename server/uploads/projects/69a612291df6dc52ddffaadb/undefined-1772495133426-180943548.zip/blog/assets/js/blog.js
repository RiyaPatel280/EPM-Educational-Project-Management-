$(function() {
    console.log('Blog JS loaded');
    var isKanban = $('#blogs_kanban_view').val() === 'true';
    if (isKanban) {
        console.log('Initializing Kanban view');
        blogs_kanban();
    } else {
        console.log('Initializing DataTable view');
        initDataTable('.table-blogs', admin_url + 'blog/table', undefined, undefined, undefined, [1, 'desc']);
    }

    // Open modal for creating new blog
    $('button[data-action="create"]').click(function() {
        console.log('New Blog button clicked');
        $('#blogModalLabel').text('<?php echo _l('new_blog'); ?>');
        $('#blog-form')[0].reset();
        $('#blog_id').val('');
        $('#name, #description').prop('disabled', false);
        $('#blogModal .modal-footer .btn-success').show();
        $('#blogModal').modal('show');
    });

    // Open modal for editing or viewing blog
    $(document).on('click', '.edit-blog, .view-blog', function(e) {
        e.preventDefault();
        console.log('Edit/View blog clicked, ID:', $(this).data('id'));
        var id = $(this).data('id');
        var isView = $(this).hasClass('view-blog');
        $.get(admin_url + 'blog/get/' + id, function(data) {
            $('#blogModalLabel').text(isView ? '<?php echo _l('view'); ?> ' + data.name : '<?php echo _l('edit'); ?> ' + data.name);
            $('#blog_id').val(data.id);
            $('#name').val(data.name).prop('disabled', isView);
            $('#description').val(data.description).prop('disabled', isView);
            $('#blogModal .modal-footer .btn-success').toggle(!isView);
            $('#blogModal').modal('show');
        }, 'json').fail(function(xhr) {
            console.error('Error fetching blog:', xhr);
            alert_float('danger', '<?php echo _l('error_occurred'); ?>');
        });
    });

    // Delete blog
    $(document).on('click', '.delete-blog', function(e) {
        e.preventDefault();
        console.log('Delete blog clicked, ID:', $(this).data('id'));
        if (confirm('<?php echo _l('confirm_delete'); ?>')) {
            var id = $(this).data('id');
            $.post(admin_url + 'blog/delete/' + id, function(response) {
                if (response.success) {
                    alert_float('success', '<?php echo _l('deleted', _l('blog')); ?>');
                    if (isKanban) {
                        blogs_kanban();
                    } else {
                        $('.table-blogs').DataTable().ajax.reload();
                    }
                } else {
                    alert_float('danger', '<?php echo _l('error_occurred'); ?>');
                }
            }, 'json').fail(function(xhr) {
                console.error('Error deleting blog:', xhr);
            });
        }
    });

    // Copy blog
    $(document).on('click', '.copy-blog', function(e) {
        e.preventDefault();
        console.log('Copy blog clicked, ID:', $(this).data('id'));
        var id = $(this).data('id');
        $.post(admin_url + 'blog/copy/' + id, function(response) {
            if (response.success) {
                alert_float('success', '<?php echo _l('copied', _l('blog')); ?>');
                if (isKanban) {
                    blogs_kanban();
                } else {
                    $('.table-blogs').DataTable().ajax.reload();
                }
            } else {
                alert_float('danger', '<?php echo _l('error_occurred'); ?>');
            }
        }, 'json').fail(function(xhr) {
            console.error('Error copying blog:', xhr);
        });
    });

    // Handle form submission
    $('#blog-form').submit(function(e) {
        e.preventDefault();
        console.log('Form submitted');
        var form = $(this);
        if (!form.find('#name').val()) {
            alert_float('danger', '<?php echo _l('please_fill_required_fields'); ?>');
            return;
        }
        $.post(form.attr('action'), form.serialize(), function(response) {
            if (response.success) {
                alert_float('success', '<?php echo _l('updated_successfully', _l('blog')); ?>');
                $('#blogModal').modal('hide');
                if (isKanban) {
                    blogs_kanban();
                } else {
                    $('.table-blogs').DataTable().ajax.reload();
                }
            } else {
                alert_float('danger', response.message || '<?php echo _l('error_occurred'); ?>');
            }
        }, 'json').fail(function(xhr) {
            console.error('Error saving blog:', xhr);
        });
    });

    // Bulk actions
    $('#blogs_bulk_action').on('click', function(e) {
        e.preventDefault();
        console.log('Bulk action triggered');
        var ids = [];
        $('.table-blogs input:checkbox:checked').each(function() {
            if ($(this).val() !== 'on') {
                ids.push($(this).val());
            }
        });
        if (ids.length > 0 && $('#mass_delete').is(':checked')) {
            if (confirm('<?php echo _l('confirm_delete'); ?>')) {
                $.post(admin_url + 'blog/bulk_delete', {ids: ids}, function(response) {
                    if (response.success) {
                        alert_float('success', '<?php echo _l('deleted', _l('blogs')); ?>');
                        $('.table-blogs').DataTable().ajax.reload();
                    } else {
                        alert_float('danger', '<?php echo _l('error_occurred'); ?>');
                    }
                }, 'json').fail(function(xhr) {
                    console.error('Error bulk deleting:', xhr);
                });
            }
        }
    });
});

// Kanban view implementation
function blogs_kanban(sortBy = 'datecreated') {
    console.log('Fetching Kanban data, sort by:', sortBy);
    $.get(admin_url + 'blog/get_kanban_data', {sort_by: sortBy}, function(data) {
        var kanban = $('#kan-ban');
        kanban.empty();
        var board = $('<div>').addClass('kanban-board tw-p-4 tw-bg-white tw-rounded-lg tw-shadow-sm');
        board.append('<h4 class="tw-font-semibold tw-mb-4">All Blogs</h4>');
        var list = $('<ul>').addClass('tw-list-none');
        data.forEach(function(blog) {
            var item = $('<li>').addClass('tw-mb-2 tw-p-2 tw-bg-gray-100 tw-rounded-md');
            item.append('<span class="tw-font-medium">' + blog.name + '</span>');
            item.append('<div class="tw-mt-2 tw-flex tw-gap-2">' +
                '<a href="#" class="view-blog tw-text-blue-600" data-id="' + blog.id + '"><i class="fa fa-eye"></i></a>' +
                '<a href="#" class="edit-blog tw-text-indigo-600" data-id="' + blog.id + '"><i class="fa fa-edit"></i></a>' +
                '<a href="#" class="delete-blog tw-text-red-600" data-id="' + blog.id + '"><i class="fa fa-trash"></i></a>' +
                '<a href="#" class="copy-blog tw-text-gray-600" data-id="' + blog.id + '"><i class="fa fa-copy"></i></a>' +
                '</div>');
            list.append(item);
        });
        board.append(list);
        kanban.append(board);
    }, 'json').fail(function(xhr) {
        console.error('Error fetching Kanban data:', xhr);
    });
}

// Kanban sort
function blogs_kanban_sort(type) {
    console.log('Sorting Kanban by:', type);
    blogs_kanban(type);
}