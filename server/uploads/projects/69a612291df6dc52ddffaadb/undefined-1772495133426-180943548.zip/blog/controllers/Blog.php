<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Blog extends AdminController
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('blog_model');
        $this->app_css->add('blog-css', module_dir_url('blog', 'assets/css/blog.css'));
    }

    public function index()
    {
        if (!has_permission('blog', '', 'view')) {
            access_denied('blog');
        }

        $data['title'] = _l('blogs');
        $data['summary'] = [
            ['id' => 1, 'name' => 'All Blogs', 'total' => $this->db->count_all(db_prefix() . 'blogs'), 'color' => '#4B5EAA']
        ];
        $data['switch_kanban'] = $this->session->userdata('blogs_kanban_view') == 'true' ? 0 : 1;
        $data['isKanBan'] = $this->session->userdata('blogs_kanban_view') == 'true';
        $this->load->view('blog/manage', $data);
    }

    public function table()
    {
        if (!has_permission('blog', '', 'view')) {
            ajax_access_denied();
        }

        $rules = [
            App_table_filter::new('name', 'TextRule')->label(_l('blog_name')),
            App_table_filter::new('datecreated', 'DateRule')->label(_l('date_created')),
        ];

        $this->app_scripts->add('blog-js', module_dir_url('blog', 'assets/js/blog.js'));

        return App_table::find('blogs')
            ->outputUsing(function ($params) {
                extract($params);

                // Temporary bypass for testing
                $has_permission_delete = true; // has_permission('blog', '', 'delete');
                $has_permission_edit = true; // has_permission('blog', '', 'edit');
                $has_permission_create = true; // has_permission('blog', '', 'create');

                $aColumns = [
                    '1', // Checkbox column
                    db_prefix() . 'blogs.id as id',
                    db_prefix() . 'blogs.name as name',
                    db_prefix() . 'blogs.datecreated as datecreated',
                ];

                $sIndexColumn = 'id';
                $sTable = db_prefix() . 'blogs';

                $where = [];
                if ($filtersWhere = $this->getWhereFromRules()) {
                    $where[] = $filtersWhere;
                }

                $result = data_tables_init($aColumns, $sIndexColumn, $sTable, [], $where, []);

                $output = $result['output'];
                $rResult = $result['rResult'];

                foreach ($rResult as $aRow) {
                    $row = [];

                    $row[] = '<div class="checkbox"><input type="checkbox" value="' . $aRow['id'] . '"><label></label></div>';

                    $row[] = '<span class="tw-font-medium">' . $aRow['id'] . '</span>';

                    $row[] = '<span class="tw-font-medium">' . e($aRow['name']) . '</span>';

                    $row[] = '<span data-toggle="tooltip" data-title="' . e(_dt($aRow['datecreated'])) . '" class="text-has-action is-date">' . e(time_ago($aRow['datecreated'])) . '</span>';

                    $actions = '<div class="tw-flex tw-gap-2">';
                    $actions .= '<a href="#" class="view-blog btn btn-info btn-sm" data-id="' . $aRow['id'] . '"><i class="fa fa-eye"></i></a>';
                    if ($has_permission_edit) {
                        $actions .= '<a href="#" class="edit-blog btn btn-primary btn-sm" data-id="' . $aRow['id'] . '"><i class="fa fa-edit"></i></a>';
                    }
                    if ($has_permission_delete) {
                        $actions .= '<a href="#" class="delete-blog btn btn-danger btn-sm" data-id="' . $aRow['id'] . '"><i class="fa fa-trash"></i></a>';
                    }
                    if ($has_permission_create) {
                        $actions .= '<a href="#" class="copy-blog btn btn-secondary btn-sm" data-id="' . $aRow['id'] . '"><i class="fa fa-copy"></i></a>';
                    }
                    $actions .= '</div>';
                    $row[] = $actions;

                    $row['DT_RowId'] = 'blog_' . $aRow['id'];
                    $row['DT_RowClass'] = 'has-row-options has-border-left';

                    $output['aaData'][] = $row;
                }

                return $output;
            })->setRules($rules);
    }

    public function get($id)
    {
        if (!has_permission('blog', '', 'view')) {
            ajax_access_denied();
        }
        $blog = $this->blog_model->get($id);
        if (!$blog) {
            show_404();
        }
        echo json_encode($blog);
    }

    public function save()
    {
        if (!has_permission('blog', '', 'create') && !has_permission('blog', '', 'edit')) {
            ajax_access_denied();
        }
        $data = $this->input->post();
        if (empty($data['name'])) {
            echo json_encode(['success' => false, 'message' => _l('please_fill_required_fields')]);
            return;
        }
        if (!empty($data['id'])) {
            if (!has_permission('blog', '', 'edit')) {
                ajax_access_denied();
            }
            $success = $this->blog_model->update($data['id'], [
                'name' => $data['name'],
                'description' => $data['description'],
            ]);
        } else {
            if (!has_permission('blog', '', 'create')) {
                ajax_access_denied();
            }
            $success = $this->blog_model->add([
                'name' => $data['name'],
                'description' => $data['description'],
                'datecreated' => date('Y-m-d H:i:s'),
            ]);
        }
        echo json_encode(['success' => $success]);
    }

    public function delete($id)
    {
        if (!has_permission('blog', '', 'delete')) {
            ajax_access_denied();
        }
        $success = $this->blog_model->delete($id);
        echo json_encode(['success' => $success]);
    }

    public function copy($id)
    {
        if (!has_permission('blog', '', 'create')) {
            ajax_access_denied();
        }
        $success = $this->blog_model->copy($id);
        echo json_encode(['success' => $success]);
    }

    public function bulk_delete()
    {
        if (!has_permission('blog', '', 'delete')) {
            ajax_access_denied();
        }
        $ids = $this->input->post('ids');
        $success = false;
        if (is_array($ids)) {
            foreach ($ids as $id) {
                $this->blog_model->delete($id);
            }
            $success = true;
        }
        echo json_encode(['success' => $success]);
    }

    public function get_kanban_data()
    {
        if (!has_permission('blog', '', 'view')) {
            ajax_access_denied();
        }
        $sort_by = $this->input->get('sort_by') ?: 'datecreated';
        $this->db->order_by($sort_by, 'desc');
        $blogs = $this->db->get(db_prefix() . 'blogs')->result_array();
        echo json_encode($blogs);
    }

    public function switch_kanban($set)
    {
        $this->session->set_userdata('blogs_kanban_view', $set == 1 ? 'true' : 'false');
        redirect(admin_url('blog'));
    }
}