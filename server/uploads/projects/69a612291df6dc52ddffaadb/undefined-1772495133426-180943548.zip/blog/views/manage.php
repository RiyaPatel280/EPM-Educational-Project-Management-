<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<?php init_head(); ?>
<div id="wrapper">
    <div class="content" id="vueApp">
        <div class="row">
            <div class="col-md-12">
                <div class="blogs-overview tw-mb-6<?php echo $isKanBan ? ' hide' : ''; ?>">
                    <h4 class="tw-my-0 tw-font-bold tw-text-xl tw-mb-2"><?php echo _l('blogs'); ?></h4>
                    <div class="tw-grid tw-gap-2 sm:tw-grid-flow-col sm:tw-auto-cols-max tw-overflow-x-auto">
                        <?php foreach ($summary as $item) { ?>
                            <button type="button" class="overview-item" disabled>
                                <span class="tw-font-semibold tw-mr-1 rtl:tw-ml-1"><?php echo $item['total']; ?></span>
                                <span class="tw-font-medium" style="color:<?php echo $item['color']; ?>">
                                    <?php echo $item['name']; ?>
                                </span>
                            </button>
                        <?php } ?>
                    </div>
                </div>

                <div class="_buttons tw-mb-2">
                    <div class="tw-flex tw-items-center tw-justify-between tw-space-x-2 rtl:tw-space-x-reverse">
                        <div class="tw-flex tw-items-center tw-space-x-1 rtl:tw-space-x-reverse">
                            <button data-action="create" class="btn btn-primary">
                                <i class="fa-regular fa-plus"></i> <?php echo _l('new_blog'); ?>
                            </button>
                            <a href="<?php echo admin_url('blog/switch_kanban/' . $switch_kanban); ?>" class="btn btn-default hidden-xs !tw-px-3" data-toggle="tooltip" data-placement="top" data-title="<?php echo $switch_kanban == 1 ? _l('blogs_switch_to_kanban') : _l('switch_to_list_view'); ?>">
                                <?php if ($switch_kanban == 1) { ?>
                                    <i class="fa-solid fa-grip-vertical"></i>
                                <?php } else { ?>
                                    <i class="fa-solid fa-table-list"></i>
                                <?php } ?>
                            </a>
                        </div>
                        <div>
                            <?php if ($isKanBan) { ?>
                                <div class="blogs-search">
                                    <div data-toggle="tooltip" data-placement="top" data-title="<?php echo _l('search_by_name'); ?>">
                                        <?php echo render_input('search', '', '', 'search', ['data-name' => 'search', 'onkeyup' => 'blogs_kanban();', 'placeholder' => _l('blogs_search')], [], 'no-margin'); ?>
                                    </div>
                                </div>
                            <?php } else { ?>
                                <div class="tw-inline">
                                    <app-filters id="blogs" view="blogs" :rules="extra.blogsRules || []" :saved-filters="[]" :available-rules="<?php echo app\services\utilities\Js::from([
                                        ['name' => 'name', 'label' => _l('blog_name'), 'type' => 'text'],
                                        ['name' => 'datecreated', 'label' => _l('date_created'), 'type' => 'date']
                                    ]); ?>">
                                    </app-filters>
                                </div>
                            <?php } ?>
                            <?php echo form_hidden('sort_type'); ?>
                            <?php echo form_hidden('sort', 'datecreated'); ?>
                            <?php echo form_hidden('blogs_kanban_view', $isKanBan ? 'true' : 'false'); ?>
                        </div>
                    </div>
                </div>

                <div class="<?php echo $isKanBan ? '' : 'panel_s'; ?>">
                    <div class="<?php echo $isKanBan ? '' : 'panel-body'; ?>">
                        <div class="tab-content">
                            <?php if ($isKanBan) { ?>
                                <div class="active kan-ban-tab tw-mt-4" id="kan-ban-tab" style="overflow:auto;">
                                    <div class="kanban-blogs-sort">
                                        <span class="bold"><?php echo _l('blogs_sort_by'); ?>: </span>
                                        <a href="#" onclick="blogs_kanban_sort('datecreated'); return false" class="datecreated">
                                            <?php echo _l('blogs_sort_by_datecreated'); ?>
                                        </a>
                                        |
                                        <a href="#" onclick="blogs_kanban_sort('name'); return false" class="name">
                                            <?php echo _l('blog_name'); ?>
                                        </a>
                                    </div>
                                    <div class="row">
                                        <div class="container-fluid blogs-kan-ban">
                                            <div id="kan-ban"></div>
                                        </div>
                                    </div>
                                </div>
                            <?php } else { ?>
                                <div class="row" id="blogs-table">
                                    <div class="col-md-12">
                                        <a href="#" data-toggle="modal" data-table=".table-blogs" data-target="#blogs_bulk_actions" class="hide bulk-actions-btn table-btn"><?php echo _l('bulk_actions'); ?></a>
                                        <div class="modal fade bulk_actions" id="blogs_bulk_actions" tabindex="-1" role="dialog">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                                                        <h4 class="modal-title"><?php echo _l('bulk_actions'); ?></h4>
                                                    </div>
                                                    <div class="modal-body">
                                                        <?php if (has_permission('blog', '', 'delete')) { ?>
                                                            <div class="checkbox checkbox-danger">
                                                                <input type="checkbox" name="mass_delete" id="mass_delete">
                                                                <label for="mass_delete"><?php echo _l('mass_delete'); ?></label>
                                                            </div>
                                                        <?php } ?>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo _l('close'); ?></button>
                                                        <a href="#" class="btn btn-primary" id="blogs_bulk_action"><?php echo _l('confirm'); ?></a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="panel-table-full">
                                            <?php
                                            $table_data = [
                                                '<span class="hide"> - </span><div class="checkbox mass_select_all_wrap"><input type="checkbox" id="mass_select_all" data-to-table="blogs"><label></label></div>',
                                                ['name' => _l('the_number_sign'), 'th_attrs' => ['class' => 'toggleable', 'id' => 'th-number']],
                                                ['name' => _l('blog_name'), 'th_attrs' => ['class' => 'toggleable', 'id' => 'th-name']],
                                                ['name' => _l('date_created'), 'th_attrs' => ['class' => 'toggleable', 'id' => 'th-datecreated']],
                                            ];
                                            render_datatable($table_data, 'blogs', ['customizable-table number-index-2'], [
                                                'id' => 'blogs',
                                                'data-last-order-identifier' => 'blogs',
                                                'data-default-order' => get_table_last_order('blogs'),
                                            ]);
                                            ?>
                                        </div>
                                    </div>
                                </div>
                            <?php } ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Blog Modal -->
<div class="modal fade" id="blogModal" tabindex="-1" role="dialog" aria-labelledby="blogModalLabel">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="blogModalLabel"><?php echo _l('new_blog'); ?></h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
            </div>
            <div class="modal-body">
                <?php echo form_open(admin_url('blog/save'), ['id' => 'blog-form']); ?>
                <input type="hidden" name="id" id="blog_id">
                <?php $this->load->view('blog/blog_form'); ?>
                <?php echo form_close(); ?>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo _l('close'); ?></button>
                <button type="submit" class="btn btn-success" form="blog-form"><?php echo _l('submit'); ?></button>
            </div>
        </div>
    </div>
</div>

<?php init_tail(); ?>
<script>
$(function() {
    new Vue({
        el: '#vueApp',
        data: {
            extra: {
                blogsRules: []
            }
        }
    });
});
</script>