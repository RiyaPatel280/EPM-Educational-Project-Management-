<?php
defined('BASEPATH') or exit('No direct script access allowed');

function blog_helper_example()
{
    return 'This is a blog helper function.';
}