<?php
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Module Name: Blog
 * Description: A simple blog module for PerfexCRM to manage articles/posts.
 * Version: 1.0
 * Author: YourName / YourCompany
 * Author URI: https://yourwebsite.com
 * Requires at least: 2.3.*
 */

define('BLOG_MODULE_NAME', 'blog');
define('BLOG_MODULE_UPLOAD_FOLDER', module_dir_path(BLOG_MODULE_NAME, 'uploads/'));

hooks()->add_action('admin_init', 'blog_module_init_menu_items');

function blog_module_init_menu_items()
{
    $CI = &get_instance();

    if (is_admin()) {
        $CI->app_menu->add_sidebar_menu_item('blog-menu', [
            'slug'     => 'blog-menu',
            'name'     => _l('blog_name'),
            'icon'     => 'fa fa-newspaper-o',
            'href'     => admin_url('blog'),
            'position' => 35,
        ]);
    }
}

register_language_files('blog', ['blog']);

register_activation_hook(BLOG_MODULE_NAME, 'blog_module_activation_hook');

function blog_module_activation_hook()
{
    $CI = &get_instance();
    require_once(__DIR__ . '/install.php');
}