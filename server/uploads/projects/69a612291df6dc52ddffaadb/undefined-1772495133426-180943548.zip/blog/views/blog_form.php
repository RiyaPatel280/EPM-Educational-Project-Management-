<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<div class="form-group">
    <label for="name"><?php echo _l('blog_name'); ?></label>
    <input type="text" name="name" id="name" class="form-control" required>
</div>
<div class="form-group">
    <label for="description"><?php echo _l('description'); ?></label>
    <textarea name="description" id="description" class="form-control" rows="6"></textarea>
</div>